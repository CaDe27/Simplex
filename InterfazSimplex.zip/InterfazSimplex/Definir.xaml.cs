﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace InterfazSimplex {
    /// <summary>
    /// Lógica de interacción para Definir.xaml
    /// </summary>
    public partial class Definir : Window {
        int variables, restricciones;
        TextBox[] tv, tr;
        ComboBox[] cv;

        public Definir(int variables, int restricciones) {
            InitializeComponent();
            this.variables = variables;
            this.restricciones = restricciones;

            tr = new TextBox[restricciones];
            for (int i = 0; i < restricciones; i++) {
                tr[i] = new TextBox();
                spr.Children.Add(tr[i]);
            }

            tv = new TextBox[variables];
            cv = new ComboBox[variables];
            for (int i = 0; i < variables; i++) {
                tv[i] = new TextBox();
                tv[i].Height = 21;
                spnv.Children.Add(tv[i]);

                cv[i] = new ComboBox();
                cv[i].Height = 21;
                cv[i].Items.Add("positiva");
                cv[i].Items.Add("libre");
                cv[i].SelectedIndex = 0;
                sptv.Children.Add(cv[i]);
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e) {

            /// escribir en problem.txt
            StringBuilder pos, lib;
            pos = new StringBuilder();
            lib = new StringBuilder();

            for (int i = 0; i < variables; i++) {
                if (cv[i].SelectedIndex == 0) {
                    if (pos.Length > 0)
                        pos.Append(",");
                    pos.Append(" ").Append(tv[i].Text);
                }
                else {
                    if (lib.Length > 0)
                        lib.Append(",");
                    lib.Append(" ").Append(tv[i].Text);
                }

            }
            pos.Insert(0, "variables positivas:");
            lib.Insert(0, "variables libres:");

            string path = @"C:\Prog Lin\InterfazSimplex\Simplex-master\problem.txt";

            using (StreamWriter sw = File.CreateText(path)) {
                sw.WriteLine(pos.ToString());
                sw.WriteLine(lib.ToString());

                if (cbtipo.SelectedIndex == 0)
                    sw.WriteLine("tipo de problema: min");
                else
                    sw.WriteLine("tipo de problema: max");

                sw.WriteLine("funcion de costo:  " + funcost.Text);

                sw.WriteLine("restricciones:");
                for (int i = 0; i < restricciones; i++) {
                    sw.WriteLine(tr[i].Text);
                }

                sw.WriteLine("fin");
            }

            /// llamar ventana final
            Window5 win5 = new Window5();
            win5.Show();
            this.Close();
        }
    }
}
