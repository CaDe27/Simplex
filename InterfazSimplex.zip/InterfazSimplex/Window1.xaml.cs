﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;

namespace InterfazSimplex {
    /// <summary>
    /// Lógica de interacción para Window1.xaml
    /// </summary>
    public partial class Window1 : Window {
        int variables, restricciones;

        public Window1(int variables, int restricciones) {
            InitializeComponent();
            this.variables = variables;
            this.restricciones = restricciones;

        }

        private void Button_Click(object sender, RoutedEventArgs e) {

            // Escribir el txt

            //variables positivas:
            //variables libres: x1, x2
            //tipo de problema: max
            //funcion de costo:  x1 + x2
            //restricciones:
            //x1 + x2 <= 15
            //x1 <= 20
            //x2 <= 1
            //fin
            StringBuilder pos, lib;
            pos = new StringBuilder();
            lib = new StringBuilder();

            TextBox[] txtres = { r1, r2, r3, r4, r5, r6, r7, r8, r9, r10 };
            ComboBox[] cbs = { cb1, cb2, cb3, cb4, cb5, cb6, cb7, cb8, cb9, cb10};
            for(int i=0; i<variables; i++) {
                if (cbs[i].SelectedIndex == 0) {
                    if (pos.Length > 0)
                        pos.Append(",");
                    pos.Append(" x").Append((i + 1));
                }
                else {
                    if (lib.Length > 0)
                        lib.Append(",");
                    lib.Append(" x").Append((i + 1));
                }

            }
            pos.Insert(0, "variables positivas:");
            lib.Insert(0, "variables libres:");

            string path = @"C:\Prog Lin\InterfazSimplex\MyTest.txt";

            using (StreamWriter sw = File.CreateText(path)) {
                sw.WriteLine(pos.ToString());
                sw.WriteLine(lib.ToString());

                if(cbtipo.SelectedIndex==0)
                    sw.WriteLine("tipo de problema: min");
                else
                    sw.WriteLine("tipo de problema: max");

                sw.WriteLine("funcion de costo:  " + funcost.Text);

                sw.WriteLine("restricciones:");
                for(int i=0; i<restricciones;i++) {
                    sw.WriteLine(txtres[i].Text);
                }
                
                sw.WriteLine("fin");
            }

            /////// abrir controlador.exe y desplegar la información en pantalla (o leerlo de algún archivo)




            // Open the file to read from.
            //using (StreamReader sr = File.OpenText(path)) {
            //    string s = "";
            //    while ((s = sr.ReadLine()) != null) {
            //        Console.WriteLine(s);
            //    }
            //}
        }
    }
}
